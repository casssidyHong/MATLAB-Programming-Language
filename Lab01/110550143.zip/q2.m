clc;

fprintf('Practices 2\n');

n = 1:1000;  
sum_fraction = sum(1 ./ n);  
disp(sum_fraction); 